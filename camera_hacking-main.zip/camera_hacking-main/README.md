<p align='center'><img style="height:100px;width:100px" src="icon.png" ></p>

<h2 align='center'>Track Down people by just using a link.</h2>

<div align="center">

[![https://telegram.me/name_dark](https://img.shields.io/badge/Telegram-Channel-orange.svg?style=flat-square)](https://t.me/name_dark)

</div>

This tool is based upon [Psi](https://github.com/MR-DARK54) .This is a telegram implementation with extra features than Psi.






### Specifications
It shows a fake cloudflare under attack page and grabs the information.
Gets The Information About browser and Device of User.
Get the exact location coordinates.
Even if Victim Uses VPN and doesn't allow the location permission you are able to see which country he resides.
Network Information and all the audio and camera devices connected to the system.
Snaps the picture from camera.








### Try it at [@camerahacking_bot](https://t.me/dark0rat54_bot)







You can create your own bot, click on 👇👇









[![Run on Repl.it](https://replit.com/badge/github/Th30neAnd0nly/TrackDown)](https://repl.it/github/MR-DARK54/camera_hacking)


 
 
 
 
 
 
 
 
 
 
### Don't forget to put a star





Buy me a coffee
I like coffee










